package com.example.flutter_assignment_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
